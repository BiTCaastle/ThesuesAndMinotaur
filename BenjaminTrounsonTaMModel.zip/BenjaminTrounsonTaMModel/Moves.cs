﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BenjaminTrounsonTaMModel
{
    public enum Moves { UP, DOWN, RIGHT, LEFT, PAUSE };
    
}
